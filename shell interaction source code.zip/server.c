//Mana Parsi ID: 73676869

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>

#define FILESZ 100000
#define LBTS 1024
#define SZ 16
#define MAXARG 220
#define HD 100
#define D " \t\r\n\a"
#define ZRO 0
#define UN 1
#define BU 64
#define THD 4

typedef struct sockaddr ADR;
static int counter;
int j;

//stack overflow code for semaphores and buffers
typedef struct{
    int num;
    int first;
    int *pt;
    int last;
    sem_t sts;
    sem_t mt;
    sem_t things;

} sbuf_t;

struct FLSM
{
    int appd;
    char inp[220];
};

struct FLSM FI[THD];
sbuf_t bufs;
static sem_t mtSec;
static sem_t mt;

void sbufInitialize(sbuf_t *p, int num)
{
    p->pt = calloc(num, sizeof(int));
    p->num = num;
    p->first = p->last = ZRO;
    sem_init(&p->mt, ZRO, UN);
    sem_init(&p->sts, ZRO, num);
    sem_init(&p->things, ZRO, ZRO);
}

void sbuDeInitialize(sbuf_t *p)
{
    //free the space
    free(p->pt);
}

void sbufIns(sbuf_t *p, int thing)
{
    //wait then post
    sem_wait(&p->sts);
    sem_wait(&p->mt);
    p->pt[(++p->last)%(p->num)] = thing;
    sem_post(&p->mt);
    sem_post(&p->things);
}

int sbufRem(sbuf_t *p)
{
    int thing;
    //wait then post
    sem_wait(&p->things);
    sem_wait(&p->mt);
    thing = p->pt[(++p->first)%(p->num)];
    sem_post(&p->mt);
    sem_post(&p->sts);
    return thing;
}

char **parser(char* l)
{
    int bufsz = BU;
    int p = 0;
    char **toks = malloc(bufsz * sizeof(char *));
    //create token
    char *tok;

    //tokenizer
    tok = strtok(l, D);
    while(tok != NULL)
    {
        toks[p] = tok;
        p++;
        //Null strtok
        tok = strtok(NULL, D);
    }
    toks[p] = NULL;
    return toks;
}

int clientOpen(char* portnum)
{
    struct addrinfo newaddr, *ls, *ptr;
    int clientd, c;
    int value = 1;

    //server addresses
    //fill with zero until we get new addresses
    memset(&newaddr, ZRO, sizeof(struct addrinfo));
    newaddr.ai_socktype = SOCK_STREAM;
    newaddr.ai_flags = AI_PASSIVE | AI_ADDRCONFIG;
    newaddr.ai_flags |= AI_NUMERICSERV;
    int i = 0;
    if((c = getaddrinfo(NULL, portnum, &newaddr, &ls)) != ZRO)
    {
        return -2;
    }

    //connect to an addr server
    for(ptr = ls; ptr; ptr = ptr->ai_next)
    {
        if((clientd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol)) < ZRO) { continue; }
        //gets rid of address in use error
        setsockopt(clientd, SOL_SOCKET, SO_REUSEADDR, (const void *) &value, sizeof(int));
        //bind
        if(bind(clientd, ptr->ai_addr, ptr->ai_addrlen) == ZRO) { break; }
        if(close(clientd) < ZRO)
        {
            return -1;
        }
    }

    //free space
    freeaddrinfo(ls);
    //if pointer not exist then return
    if(!ptr) { return -1; }
    
    if(listen(clientd, 1024) < ZRO) {
        close(clientd);
        // close and return
        return -1;
    }
    return clientd;
}

void defaultF()
{
    //initialize file array
    for(j = 0; j < THD; j++)
    {
        //initialize with zero
        FI[j].appd = ZRO;
        //initialize with empty
        strcpy(FI[j].inp, "");
    }
    sem_init(&mtSec, ZRO, UN);
}

void RDFL(char* word)
{
    for(j = 0; j < THD; j++)
    {
        //check if array is empty string
        if(strcmp(FI[j].inp, "")==ZRO)
        {
            //initialize with zero
            FI[j].appd = ZRO;
            //initialize with word
            strcpy(FI[j].inp, word);
            break;
        }
    }
}

void APFL(char* word)
{
    for(j = 0; j < THD; j++)
    {
        //check if array is empty string
        if(strcmp(FI[j].inp, "")==ZRO)
        {
            //initialize with one
            FI[j].appd = UN;
            //initialize with word
            strcpy(FI[j].inp, word);
            break;
        }
    }
}

void RMFL(char* word)
{
    for(j = 0; j < THD; j++)
    {
        //check if array is empty string
        if(strcmp(FI[j].inp, word)==ZRO)
        {
            //initialize with zero
            FI[j].appd = ZRO;
            //initialize with empty string
            strcpy(FI[j].inp, "");
            break;
        }
    }
}

int AD(char* word)
{
    for(j = 0; j < THD; j++)
    {
        //check if array is already has word
        if(strcmp(FI[j].inp, word)==ZRO)
        {
            if(FI[j].appd == UN)
            {
                return UN;
            }
        }
    }
    return ZRO;
}

int RD(char* word)
{
    for(j = 0; j < THD; j++)
    {
        //check if array is already has word
        if(strcmp(FI[j].inp, word)==ZRO) { return UN; }
    }
    return ZRO;
}

static void initializeEch(void)
{
    //set counter
    counter = ZRO;
    sem_init(&mt, ZRO, UN);
}

void ServEcho(int cfd)
{
    char blank[220] = "nothing";
    char **argv2;
    char buffer[220];
    FILE *fe;
    char inpt[220];
    int lstbyt = UN;
    int FOpn = ZRO;
    int sw = 4;
    static pthread_once_t oe = PTHREAD_ONCE_INIT;
    int num;
    pthread_once(&oe, initializeEch);
    while((num = read(cfd, buffer, 220)) != ZRO)
    {
        char inpt[220];
        sem_wait(&mt);
        char pr[220];
        counter = counter + num;
        printf("%s", buffer);
        argv2 = parser(buffer);

        if(strcmp(*argv2, "openAppend") == ZRO)
        {
            //need to sem wait
            sem_wait(&mtSec);
            if(RD(argv2[1]) == UN && FOpn == ZRO)
            {
                //need to print for user
                char result[220] = "The file is open by another client.";
                //print the result
                printf("%s\n", result);
                //write to client
                write(cfd, result, 220);
            }
            else if(RD(argv2[1]) == ZRO && FOpn == ZRO)
            {
                fe = fopen(argv2[1], "a");
                int works = 2;
                FOpn = UN;
                APFL(argv2[1]);
                write(cfd, blank, 220);
            }
            else
            {
                //need to print for user
                char result[220] = "A file is already open for appending.";
                //print the result
                printf("%s\n", result);
                //write to client
                write(cfd, result, 220);   
            }
            //need sem post
            sem_post(&mtSec);
        }

        else if(strcmp(*argv2, "openRead")==ZRO)
        {
            //need sem wait
            sem_wait(&mtSec);
            if(AD(argv2[1]) == UN && FOpn == ZRO)
            {
                //need to print for user
                char result[220] = "The file is open by another client.";
                //print the result
                printf("%s\n", result);
                //write to client
                write(cfd, result, 220);
            }
            else if(AD(argv2[1]) == ZRO && FOpn == ZRO)
            {
                //open and read the file
                fe = fopen(argv2[1], "rb");
                //change file status
                FOpn = UN;
                int works = 2;
                RDFL(argv2[1]);
                write(cfd, blank, 220);
            }
            else
            {
                //need to print for user
                char result[220] = "A file is already open for reading.";
                //print the result
                printf("%s\n", result);
                int works = 3;
                //write to client
                write(cfd, result, 220);
            }
            //need sem post
            sem_post(&mtSec);
        }

        else if(strcmp(*argv2, "append") == ZRO)
        {
            char arguments[220];
            if(fe)
            {
                fprintf(fe, argv2[1]);
                int works = 2;
                write(cfd, blank, 220);
            }
            else
            {
                int works = 3;
                //print file not found
                char result[220] = "File not open.";
                //write the result
                write(cfd, result, 220);
            }
        }

        else if(strcmp(*argv2, "read") == ZRO)
        {
            char arguments[220];
            if(fe)
            {
                if(fgets(arguments, 1+atoi(argv2[1]), fe) != NULL) {
                    int works = 1;
                    write(cfd, arguments, 220);
                }
                else{
                    write(cfd, blank, 220);
                }
            }
            else
            {
                //write result to client
                int works = 2;
                char result[220] = "File not open.";
                //send the result to client
                write(cfd, result, 220);
            }
        }

        else if(strcmp(*argv2, "close")==ZRO)
        {
            FOpn = ZRO;
            //need sem wait
            sem_wait(&mtSec);
            RMFL(argv2[1]);
            //need sem post
            sem_post(&mtSec);
            int works = 1;
            fclose(fe);
            fe = NULL;
            write(cfd, blank, 220);
        }

        sem_post(&mt);
    }
}
void *td(void *arg)
{
    pthread_detach(pthread_self());
    while(1)
    {
        int cfd = sbufRem(&bufs);
        ServEcho(cfd);
        close(cfd);
    }
}

int main(int argc, char **argv)
{
    int listend, cfd;
    int j;
    pthread_t t;
    int chk = 2;
    struct sockaddr_storage caddr;
    socklen_t clen;
    //check if argc is not 2
    if(argc != chk)
    {
        exit(0);
    }

    listend = clientOpen(argv[1]);
    int works = 1;
    printf("server started\n");
    defaultF();
    int dint = 0;
    sbufInitialize(&bufs, SZ);
    for(j = 0; j < 4; j++) { pthread_create(&t, NULL, td, NULL); }

    while(1)
    {
        clen = sizeof(struct sockaddr_storage);
        //accept socket
        cfd = accept(listend, (ADR *) &caddr, &clen);
        sbufIns(&bufs, cfd);
    }
}