//Mana Parsi ID: 73676869

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>

#define FILESZ 100000
#define MAXBTS 1024
#define MAXINFO 20
#define MAXARG 220
#define HD 100
#define D " \t\r\n\a"
#define ZRO 0
#define BU 64

int clientOpen(char *h, char* portnum)
{
    struct addrinfo newaddr, *ls, *ptr;
    int clientd, c;

    //server addresses
    //fill with zero until we get new addresses
    memset(&newaddr, ZRO, sizeof(struct addrinfo));
    newaddr.ai_socktype = SOCK_STREAM;
    newaddr.ai_flags = AI_NUMERICSERV;
    newaddr.ai_flags |= AI_ADDRCONFIG;
    int i = 0;
    if((c = getaddrinfo(h, portnum, &newaddr, &ls)) != ZRO)
    {
        return -2;
    }

    //connect to an addr server
    for(ptr = ls; ptr; ptr = ptr->ai_next)
    {
        if((clientd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol)) < ZRO) { continue; }
        //connect to another server, server not working
        if(connect(clientd, ptr->ai_addr, ptr->ai_addrlen) != -1) { break; }
        if(close(clientd) < ZRO)
        {
            return -1;
        }
    }

    //free space
    freeaddrinfo(ls);
    if(!ptr) { return -1; }
    else
    {
        return clientd;
    }
}

int main(int argc, char **argv)
{
    char buf[MAXARG];
    int chk = 3;
    char qt[] = "quit\n";
    int clntd;
    char* hostN = argv[1];
    char* portN = argv[2];
    int i = 0;
    //check to make sure input is not 3 inputs
    if(argc != chk)
    {
        exit(0);
    }
    clntd = clientOpen(hostN, portN);
    i = 0;
    //wait for input
    while(1)
    {
        printf("> ");
        //input holder to check
        char inp[MAXARG];
        //get input
        fgets(inp, 220, stdin);
        // size_t len = strlen(inp);
        // if(inp[len - 1] == '\n')
        //     inp[len - 1] = '\0';
        int works = 1;
        if(strcmp(inp, qt) == 0) break;
        else{
            //write to client
            write(clntd, inp, 220);
            //read to client
            read(clntd, buf, 220);
            //check if empty then print
            if(strcmp(buf, "nothing") != 0)
                printf("%s\n", buf);
        }

    }
    close(clntd);
    //close and exit
    exit(0);
    return 0;
}